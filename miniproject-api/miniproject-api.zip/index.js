const { Sequelize, DataTypes } = require('sequelize');
const port = 2000;
const DB_URL = 'postgres://postgres:root@localhost:5432/MoviesDB';
const express = require('express');

const sq = new Sequelize(DB_URL);
const app = express();
app.use(express.json());
app.use(require('cors')())


const Wishtlist = sq.define('Wishlist', {
    imdbID: { type: DataTypes.STRING, primaryKey: true },
}, {timestamps:false, freezeTableName:true});

app.get('/wishlist', async (req, res) => {
    try {
        res.json(await Wishtlist.findAll({}));
    } catch (err) {
        console.error(err);
        res.json(err);
    }
});

app.post('/wishlist/:imdbID', async ({params:{imdbID}}, res) => {
    try {
        const movie = await Wishtlist.findOne({where:{imdbID}});
        console.log(movie);
        if (movie){
            res.json(await movie.destroy());
        }else{
            res.json(await Wishtlist.create({imdbID}));
        }
    } catch (err) { console.log(err); res.json(err); }
});






app.listen(port || 2000);

sq.sync({ alter: true })
    .then(() => {
        return;
    })
    .catch((err) => {
        console.log(err);
    });     