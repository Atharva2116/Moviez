import { useState, useEffect } from 'react';
const api_url = 'http://localhost:2000/wishlist';
// MovieCard component
const MovieCard = ({ movie, toggleWishlist, isInWishlist }) => {
  return (
    <div key={movie.imdbID} className="movie-card">
      <img src={movie.Poster} alt={movie.Title} />
      <h2>{movie.Title}</h2>
      <h2>{movie.imdbID}</h2>
      <button onClick={() => toggleWishlist(movie.imdbID)} className={isInWishlist ? 'heart active' : 'heart'}>
        {isInWishlist ? 'Remove from Wishlist' : 'Add to Wishlist'}
      </button>
    </div>
  );
};

// MoviesGrid component
const MoviesGrid = ({ onlyWishlist }) => {

  const [movies, setMovies] = useState([]);
  const [wishlist, setWishlist] = useState([]);
  const fetchWishlist = async () => {
    const res = await fetch(api_url, {

    });
    const data = await res.json();
    setWishlist(data.map(d => d.imdbID));
  }

  useEffect(() => { fetchWishlist() }, []);

  const fetchMovies = async () => {
    var omdbApi, res, data;
    if (onlyWishlist) {
      var results = []
      for (var w of wishlist) {
        omdbApi = 'http://www.omdbapi.com/?apikey=9835f5f1&i=' + w;
        res = await fetch(omdbApi);
        data = await res.json();
        results.push(data);
      }
      setMovies(results);
      console.log(results);
    }
    else {

      omdbApi = 'http://www.omdbapi.com/?apikey=9835f5f1&s=kill';
      res = await fetch(omdbApi);
      data = await res.json();
      setMovies(data.Search);
    }



  };


  useEffect(() => {
    fetchMovies();
  }, [wishlist]);



  const toggleWishlist = async (imdbID) => {

    await fetch(`${api_url}/${imdbID}`, {
      method: "POST",

    });
    await fetchWishlist();
  }

  return (
    <section className="movies-section">
      <div className="movies-grid">
        <div className="grid-table">
          {movies.map((movie) => (
            <MovieCard key={movie.imdbID} toggleWishlist={toggleWishlist} movie={movie} isInWishlist={wishlist.includes(movie.imdbID)} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default MoviesGrid;
