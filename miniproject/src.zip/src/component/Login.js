import React, { useState } from "react";
import "./Login.css";
import { useNavigate } from "react-router-dom";
function LoginForm() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [signupUsername, setSignupUsername] = useState('');
  const [email, setEmail] = useState('');
  const [signupPassword, setSignupPassword] = useState('');
  const [showLoginForm, setShowLoginForm] = useState(true);
  const navigate=useNavigate();
  const handleLogin = (event) => {
    event.preventDefault();
    if (username.trim() === '' || password.trim() === '') {
      alert('Enter again');
    } else {
      // Perform login logic
      localStorage.setItem('username', username);
      localStorage.setItem('passwordValue', password);
      alert('Successfully logged in');
      navigate("/home")
      // Redirect or navigate to dashboard page
      // Example: window.location.href = "/dashboard";
    }
  };

  const handleSignup = (event) => {
    event.preventDefault();
    if (
      signupUsername.trim() === '' ||
      email.trim() === '' ||
      signupPassword.trim() === ''
    ) {
      alert('Enter all required fields');
    } else {
      // Perform signup logic
      alert('Successfully registered');
      const userData = {
        username: signupUsername,
        email: email,
        password: signupPassword
      };
      localStorage.setItem('userData', JSON.stringify(userData));
      navigate("/home")
      
      
    }
  };

  const toggleForm = () => {
    setShowLoginForm(!showLoginForm);
  };

  return (
    
    
      
    <div className="background-container1">
    <div className="container1">
      {showLoginForm ? (
        <form id="login" onSubmit={handleLogin}>
          <h1 id="head">Login</h1>
          <p className="text required">Username</p>
          <input
            required
            type="text"
            placeholder="username"
            className="input"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <br />
          <p className="text required">Password</p>
          <input
            required
            type="password"
            placeholder="password"
            className="input"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <br />
          <button id="btn" type="submit">Sign in</button>
          <p className="content">Does not have account ?</p>
          <button id="btn-up" type="button" onClick={toggleForm}>
            Sign up
          </button>
        </form>
      ) : (
        <form id="login" onSubmit={handleSignup}>
          <h1 id="head">Sign up</h1>
          <p className="text required">Username</p>
          <input
            type="text"
            required
            placeholder="username"
            className="input"
            value={signupUsername}
            onChange={(e) => setSignupUsername(e.target.value)}
          />
          <br />
          <p className="text required">Email</p>
          <input
            type="email"
            required
            placeholder="email"
            className="input"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <br />
          <p className="text required">Password</p>
          <input
            type="password"
            required
            placeholder="password"
            className="input"
            value={signupPassword}
            onChange={(e) => setSignupPassword(e.target.value)}
          />
          <br />
         
          <button id="btn" type="submit">Register</button>
          <p className="content">Already have an account ?</p>
          <button id="btn-up" type="button" onClick={toggleForm}>
            Login
          </button>
        </form>
      )}
    </div>
  </div>
 
  );
};

export default LoginForm;
