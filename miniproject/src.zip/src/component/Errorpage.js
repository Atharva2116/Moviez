import React from 'react'

const Errorpage = () => {
  return (
    <div>Error page</div>
  )
}

export default Errorpage