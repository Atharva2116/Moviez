import "bootstrap"
import React from 'react';
import MoviesGrid from "./MoviesGrid";
import Navbar from "./Navbar";
const Wishlist = () => {
  return (
    <>
      <section className='wishlist-section'>
        <Navbar/>
      </section>
      <MoviesGrid onlyWishlist={true} />
      
    </>
  );
  };
  
  export default Wishlist;