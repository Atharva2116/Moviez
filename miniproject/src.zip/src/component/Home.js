import React from 'react';
import "bootstrap";
import images from "./images/action.jpg"
import image1 from "./images/action.jpg";
import image2 from "./images/comdey.jpg";
import image3 from "./images/horror.jpg";
import SimpleImageSlider from "react-simple-image-slider";
import "./Home.css"
import Navbar from "./Navbar";
import MoviesGrid from './MoviesGrid';

const movies = [
  {
    id: 1,
    title: 'The Shawshank Redemption',
    image: 'https://example.com/shawshank_redemption.jpg',
  },
  {
    id: 2,
    title: 'The Godfather',
    image: 'https://example.com/godfather.jpg',
  },
  // Add more movie objects as needed
];


function Home() {

  const image_slider = [
    { url: image1 },
    { url: image2 },
    { url: image3 }
  ];

  return (
    <>
      <section className='home-section'>
        <Navbar/>
        <div className='cont'>
          <SimpleImageSlider
            width={"90%"}
            height={"80%"}
            images={image_slider}
            showNavs={true}
            className="sliding-container" // Add the class name here
            imageClass="slider-image" // Add the image class here
          />
        </div>
      </section>
      <MoviesGrid onlyWishlist={false} />
      
    </>
  );
}

export default Home;
